# Rendor Mobile Bundle

This folder is a portable backend bundle copied from the main project for mobile-app work.

It includes the core Python strategy engine files:

- `dataset_loader.py`
- `evaluator.py`
- `game_theory.py`
- `gametheory.py`
- `graph_model.py`
- `market_data.py`
- `predictive_models.py`
- `reinforcement_model.py`
- `rlagent.py`
- `strategy_signal_rl.py`

It also includes the copied data and checkpoint artifacts needed for a mobile demo flow:

- `data/competitors_by_category.json`
- `models/heuristic_checkpoint.json`
- `models/strategysignal_rl_policy.json`
- `models/strategysignal_predictive.joblib`
- `models/scenario_snapshot.json`

The copied `scenario_snapshot.json` has already been rewritten to use the local `rendor/models` paths.

Use this bundle when you want a mobile app backend without the Streamlit UI. The Streamlit-specific files were intentionally left out:

- `app.py`
- `streamlit_app.py`
- `.streamlit/`
- `assets/`

Typical mobile-backend entry points:

- `load_scenario_from_checkpoints()` from `dataset_loader.py` for fast saved-checkpoint demos
- `evaluate_strategy()` from `evaluator.py` for manual strategy input flows

Install dependencies from this folder with:

```bash
pip install -r requirements.txt
```

Then load the saved scenario with:

```python
from dataset_loader import load_scenario_from_checkpoints

scenario = load_scenario_from_checkpoints()
```
